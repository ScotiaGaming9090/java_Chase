var manifest = [
    {
        src:"lib/assets.json",
        forSpritesheet:"uiAssets"
    },
    {
        src:"lib/assets.png",
        id:"uiAssets"
    },
    {
        src:"lib/boing.ogg",
        id:"boing",
        data:4
    }
];